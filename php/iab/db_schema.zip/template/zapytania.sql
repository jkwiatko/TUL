use PortalA;

SELECT UserPremises.id,name,login FROM UserPremises
INNER JOIN User
ON UserPremises.user_id = User.id
ORDER BY UserPremises.id;

SELECT * FROM Administrator
WHERE id IN (
	SELECT administrator_id 
    FROM AdministratorProperty
	WHERE property_id IN (
		SELECT Property.id
		FROM Property
		WHERE city Like 'L%'
));

SELECT concat(nazwa, ' login: ', login) AS MONTHLY
FROM Administrator;

SELECT name, city
FROM Administrator, Property
WHERE Administrator.id = Property.id;

SELECT e.id,city,street,p.number,e.number AS numer_lokalu
FROM Premises e
LEFT JOIN Property p -- Magia z tym 'p'
ON property_id = p.id
ORDER BY city;

SELECT city, street, Property.number, 
	Premises.number AS 'NUMER LOKALU' FROM Property,Premises
WHERE Property.id = property_id AND Premises.number IN ('23c','10a','8') 
ORDER BY city;

SELECT Room.name, Premises.number
FROM Room
NATURAL JOIN Premises;

SELECT city
FROM Property
UNION ALL
SELECT city
FROM Property;

SELECT AddRandomReadToWM2(1, 7);

TRUNCATE Reading; -- czyści tabele
SELECT * FROM Reading;
SELECT COUNT(*) FROM Watermeter;

CALL AddManyReadings(5,4,1);
CALL AddManyRandomReadings(10);
SELECT AddRandomNieruchomosc();
CALL AddManyRandomProperty(10);
SELECT AddRandomPremises();
CALL AddManyRandomPremises(10);

SET @salt = "@#$%^&*";
SELECT MD5("Adam"+@salt), md5("coś nowego" + @salt);

CALL AddManyRandomUser(10);
CALL AddManyRandomAdm(10);

SELECT * FROM Nieruchomosc ;
SELECT * FROM Lokal ;

SELECT MD5("Ala ma kota"), MD5("Ala ma koty");

SELECT AddRandomLokal();

use PortalA;
DELETE FROM Property WHERE id = 1;

select max(dlugosc) as MAX_COUNT
from (select character_length(nazwa) as dlugosc from slownik.ulice) ulice;

SELECT nazwa, character_length(nazwa) AS dlugosc
FROM slownik.ulice
GROUP BY nazwa
ORDER BY dlugosc desc;

DROP DATABASE PortalA;
use PortalA;
SELECT * FROM Administrator;