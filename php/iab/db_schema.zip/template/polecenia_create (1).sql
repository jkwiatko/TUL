CREATE DATABASE IF NOT EXISTS PortalA;
CREATE TABLE IF NOT EXISTS Pokoj
(
	id INT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
    nazwa VARCHAR(32) NOT NULL
);
CREATE TABLE IF NOT EXISTS Rodzaj
(
	id INT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
    nazwa VARCHAR(32) NOT NULL
);
/*THAT IS ALL*/
--------------------------------
CREATE TABLE IF NOT EXISTS Administrator
(
	id INT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
    nazwa VARCHAR(32) NULL,
    login VARCHAR(32) NOT NULL UNIQUE,
    haslo VARCHAR(32) NOT NULL,
    aktywny INT NOT NULL
);
--------------------------------
CREATE TABLE IF NOT EXISTS Uzytkownik
(
	id INT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
    nazwa VARCHAR(32) NULL,
    login VARCHAR(32) NOT NULL UNIQUE,
    haslo VARCHAR(32) NOT NULL,
    aktywny INT NOT NULL
);
--------------------------------
CREATE TABLE IF NOT EXISTS Nieruchomosc
(
	id INT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
    miasto VARCHAR(32) NULL, 
    ulica VARCHAR(32) NULL, 
    numer VARCHAR(5) NULL
);
--------------------------------
CREATE TABLE IF NOT EXISTS AdministratorNieruchomosc
(
	id INT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
    administrator_id INT UNSIGNED,
    nieruchomosc_id INT UNSIGNED,
    
    CONSTRAINT administrator_fk FOREIGN KEY (administrator_id)
    REFERENCES Administrator(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
    
    CONSTRAINT nieruchomosc_fk FOREIGN KEY (nieruchomosc_id)
    REFERENCES Nieruchomosc(id)
    ON DELETE CASCADE ON UPDATE CASCADE
);
--------------------------------
CREATE TABLE IF NOT EXISTS Lokal
(
	id INT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
    nieruchomosc_id INT UNSIGNED, 
    numer VARCHAR(5),
	
    CONSTRAINT nieruchomosc_fk_l FOREIGN KEY (nieruchomosc_id)
	REFERENCES Nieruchomosc(id)
    ON DELETE CASCADE ON UPDATE CASCADE 
);

CREATE TABLE IF NOT EXISTS UzytkownikLokal
(
	id INT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
    uzytkownik_id int unsigned,
    lokal_id int unsigned,
    
    CONSTRAINT uzytkownik_fk FOREIGN KEY (uzytkownik_id)
    REFERENCES Uzytkownik(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
    
    CONSTRAINT lokal_fk FOREIGN KEY (lokal_id)
    REFERENCES Lokal(id)
    ON DELETE CASCADE ON UPDATE CASCADE
);
--------------------------------
CREATE TABLE IF NOT EXISTS Wodomierz
(
	id INT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
    lokal_id INT UNSIGNED NOT NULL,
    rodzaj_id INT UNSIGNED NOT NULL, 
    pokoj_id INT UNSIGNED NOT NULL, 
    numer INT UNSIGNED NOT NULL UNIQUE,
    
	CONSTRAINT lokal_fk_w FOREIGN KEY (lokal_id)
	REFERENCES Lokal(id)
    ON DELETE CASCADE ON UPDATE CASCADE, 
    
    CONSTRAINT rodzaj_fk FOREIGN KEY (rodzaj_id)
    REFERENCES Rodzaj(id)
    ON DELETE CASCADE ON UPDATE CASCADE,
    
    CONSTRAINT pokoj_fk FOREIGN KEY (pokoj_id)
    REFERENCES Pokoj(id)
    ON DELETE CASCADE ON UPDATE CASCADE
);
--------------------------------
CREATE TABLE IF NOT EXISTS Odczyt
(
	ID INT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
    wodomierz_id INT UNSIGNED NOT NULL,
    data_odczytu date NOT NULL,
    value FLOAT NOT NULL,
    
    CONSTRAINT wodomierz_fk_o FOREIGN KEY (wodomierz_id)
    REFERENCES Wodomierz(id)
    ON DELETE CASCADE ON UPDATE CASCADE
);
---------------------------------
