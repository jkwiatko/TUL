use PortalA;
SELECT AddRandomUser();
