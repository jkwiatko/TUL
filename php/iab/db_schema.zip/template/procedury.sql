use PortalA;
DELIMITER //
DROP PROCEDURE IF EXISTS AddManyRandomAdm //
CREATE PROCEDURE AddManyRandomAdm(_amount INT)
BEGIN
	WHILE _amount > 0 DO
		SELECT AddRandomAdm(8,20);
        SET _amount = _amount - 1;
	END WHILE;
END //
----------------------------------------------------------
DROP PROCEDURE IF EXISTS AddManyRandomUser //
CREATE PROCEDURE AddManyRandomUser(_amount INT)
BEGIN
	WHILE _amount > 0 DO
		SELECT AddRandomUser(8,20);
        SET _amount = _amount - 1;
	END WHILE;
END //
----------------------------------------------------------
DROP PROCEDURE IF EXISTS AddManyReadings //
CREATE PROCEDURE AddManyReadings(_amount INT, _watermeterID INT, _peroid INT)
BEGIN
	DECLARE n INTEGER;
    SET n = _amount;
	WHILE n > 0 DO
		SELECT AddRandomReadToWM(_watermeterID, _peroid);
        SET n = n - 1;
	END WHILE;
END //
----------------------------------------------------------
DROP PROCEDURE IF EXISTS AddManyRandomReadings //
CREATE PROCEDURE AddManyRandomReadings(_amount INT)
BEGIN
	DECLARE n INTEGER;
    DECLARE watermeter_id INT;
    DECLARE days INT;
    
    SET n = (SELECT MAX(id) FROM Watermeter); -- założenie:
    /*w trakcie wykonywania procedury 
    liczba wodomierzy nie zmieni się*/
	WHILE _amount> 0 DO
		SET watermeter_id = n*RAND();
		SET days = 1+RAND()*7;
		SELECT AddRandomReadToWM(watermeter_id, days);
        SET _amount = _amount - 1;
	END WHILE;
END //
----------------------------------------------------------
DROP PROCEDURE IF EXISTS AddManyNieruchomosci//
CREATE PROCEDURE AddManyNieruchomosci(_amount INT UNSIGNED, _id INT UNSIGNED, _max_number INT)
BEGIN
    DECLARE last_id,rand_number INT UNSIGNED;
    IF _id IS NOT NULL THEN -- to czy mamy _id jest pierwszorzędne
        IF _max_number IS NULL THEN
			WHILE _amount > 0 DO
				SET last_id    = (SELECT AddRandomNieruchomosc(_id, NULL));
                SET _amount    = _amount -1;
			END WHILE;
		ELSE
			WHILE _amount > 0 DO
				SET rand_number = 1 + RAND()*_max_number;
				SET last_id     = (SELECT AddRandomNieruchomosc(rand_number, _id)); -- przypisanie spowoduje nie wysyłanie wyniku na ekran
				SET _amount     = _amount - 1;
			END WHILE;
		END IF;
	ELSE
        WHILE _amount > 0 DO
            SET last_id    = (SELECT AddRandomNieruchomosc(NULL, NULL)); -- przypisanie spowoduje nie wysyłanie wyniku na ekran
            SET _amount    = _amount - 1;
        END WHILE;
    END IF;
END//
----------------------------------------------------------
DELIMITER ;