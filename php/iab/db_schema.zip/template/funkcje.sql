DELIMITER //
DROP FUNCTION IF EXISTS AddRandomReadToWM //
CREATE FUNCTION AddRandomReadToWM(_Watermeter_ID INT, _period INT) RETURNS INT
BEGIN
	DECLARE rdate, ldate DATE;
	DECLARE rvalue, lvalue FLOAT;

	SELECT MAX(data_odczytu) FROM Odczyt INTO ldate;
	-- SELECT data_odczytu, wartosc FROM Odczyt ORDER BY data_odczytu DESC LIMIT 1;

	IF ldate IS NULL THEN
		SET ldate = '2017-03-14';
		SET lvalue = 0;
	ELSE
		SELECT IFNULL(value, 0) FROM Odczyt WHERE data_odczytu = ldate LIMIT 1 INTO lvalue;
	END IF;

	SET rdate  = DATE_ADD(ldate, INTERVAL _period DAY);
	SET rvalue = lvalue + RAND() * 100 - 10;

	INSERT INTO Odczyt VALUES(NULL, _Watermeter_ID, rdate, rvalue) ;
	RETURN LAST_INSERT_ID();
END//
----------------------------------------------------------
DROP FUNCTION IF EXISTS AddRandomWatermeter // -- numer nie może się powtarzać
CREATE FUNCTION AddRandomWatermeter (_permises_id INT UNSIGNED, _water_id INT UNSIGNED,
	_room_id INT UNSIGNED) RETURNS INT
BEGIN
	DECLARE rnumber INT UNSIGNED;
    SET rnumber = RAND()*10000;
    INSERT INTO Wodomierz VALUES 
		(NULL,_permises_id,_water_id,_room_id, rnumber);
	RETURN LAST_INSERT_ID();
END //
----------------------------------------------------------
DROP FUNCTION IF EXISTS AddRandomAdm //
CREATE FUNCTION AddRandomAdm (min INT, max INT) RETURNS INT
BEGIN
	DECLARE rpassword VARCHAR(32);
    DECLARE rlogin VARCHAR(32);

		SET rlogin = RndStr(min,max);
		SET rpassword = MD5(RndStr(min,max));

	INSERT INTO Administrator VALUES (NULL,NULL,rlogin,rpassword,0);
    RETURN LAST_INSERT_ID();
END //
----------------------------------------------------------
DROP FUNCTION IF EXISTS AddRandomUser //
CREATE FUNCTION AddRandomUser (min INT, max INT) RETURNS INT
BEGIN
	DECLARE rpassword VARCHAR(32);
    DECLARE rlogin VARCHAR(32);

		SET rlogin = RndStr(min,max);
		SET rpassword = MD5(RndStr(min,max));

	INSERT INTO Uzytkownik VALUES (NULL,NULL,rlogin,rpassword,0);
    RETURN LAST_INSERT_ID();
END //
----------------------------------------------------------
DROP FUNCTION IF EXISTS AddRandomNieruchomosc//
CREATE FUNCTION AddRandomNieruchomosc( _number CHAR(4), _id INT UNSIGNED) RETURNS INT
BEGIN -- _id to id istniejącej nieruchomości, _number to jaki numer ma być wstawiony
    DECLARE city   VARCHAR(30);
    DECLARE street VARCHAR(64);
    DECLARE rand_number, rand_city_id, rand_street_id INT;
    DECLARE nier_exists BOOL;
    IF _id IS NULL THEN -- jeśli nie mamy _id to wykonujemy po staremu
		REPEAT
			SET rand_number    = RAND()*200 + 1;
			SET rand_street_id = RAND()*(SELECT COUNT(*) FROM slownik.ulice)+1;
			SET rand_city_id   = RAND()*(SELECT COUNT(*) FROM slownik.miasta)+1;
			SET city        = (SELECT miasto FROM slownik.miasta WHERE id = rand_city_id);
			SET street      = (SELECT nazwa FROM slownik.ulice WHERE id = rand_street_id);
			SET nier_exists = (SELECT id FROM Nieruchomosc WHERE (miasto = city) AND (ulica = street) AND (numer = rand_number) LIMIT 1) IS NOT NULL;
		UNTIL NOT nier_exists END REPEAT;
	ELSE
		IF _number IS NULL THEN
			REPEAT
				SET rand_number	= RAND()*200 + 1; -- rand zwraca flota, niedobrze, dlatego tak udziwniłem
				SET street      = (SELECT ulica FROM Nieruchomosc WHERE id=_id limit 1);
				SET city        = (SELECT miasto FROM Nieruchomosc WHERE id=_id limit 1);
				SET nier_exists = (SELECT id FROM Nieruchomosc WHERE (miasto = city) AND (ulica  = street) AND (numer = rand_number) LIMIT 1) IS NOT NULL;
			UNTIL NOT nier_exists END REPEAT;
		ELSE
			SET street = (SELECT ulica FROM Nieruchomosc WHERE id=_id limit 1);
			SET city = (SELECT miasto FROM Nieruchomosc WHERE id=_id limit 1);
            SET rand_number = _number;
		END IF;
	END IF;
    
    INSERT INTO Nieruchomosc VALUES (null, city, street, rand_number);
    RETURN LAST_INSERT_ID();
END//
-------------------------------------------------------------------------------

DELIMITER ;
/*DROP FUNCTION IF EXISTS*/