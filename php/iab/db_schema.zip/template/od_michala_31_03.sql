Poprawki

USE PortalA;
ALTER TABLE Nieruchomosc MODIFY ulica VARCHAR(64) CHARACTER SET cp1250 NULL;

/*
    po '=' spacja (i przed też)
    po ',' spacja
    słowa kluczowe z wielkich liter (SELECT FROM INTO itd)

    UNTIL... w jednej linii z END REPEAT

    w warunkach wyrażenia między operatorami logicznymi pisać w nawiasach!

    wprowadzić bardziej zrozumiałe nazwy zmiennych lub komentować funkcje (np. przed nagłówkiem).

    jeśli używamy SELECT do uruchomienia funkcji i nie potrzebujemy wyniku, to należy wynik wysłać do nieznaczącej zmiennej (patrze AddManyNieruchomosci)

    FUNKCJE a PROCEDURY

    funkcje wywołujemy przez SELECT...
    procedury przez CALL...

    to oznacza, że łatwo iterować funkcję (n razy) bez użycia pętli...

    funkcja zwraca 1 paramter
    procedura zwraca tabelę...

    jeśli chcemy np. zwracać id dodanego rekordu, to lepiej użyć funkcji...

*/

-- 
-------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Zmieniona AddManyNieruchomosci (dodana funkcjonalnosc)
DELIMITER  $$
DROP PROCEDURE IF EXISTS AddManyNieruchomosci$$
CREATE PROCEDURE AddManyNieruchomosci(_amount INT UNSIGNED, _max int unsigned)
BEGIN
    DECLARE last_id, rand_max     INT UNSIGNED;
    IF _max IS NOT NULL THEN
        SET last_id    = (SELECT AddRandomNieruchomosc(_max, NULL));
        WHILE _amount > 1 DO
            REPEAT
                SET rand_max = RAND() * _max + 1;
            UNTIL NOT rand_max = _max END REPEAT;

            SET _max     = rand_max;
            SET last_id    = (SELECT AddRandomNieruchomosc(_max, last_id)); -- przypisanie spowoduje nie wysyłanie wyniku na ekran
            SET _amount    = _amount - 1;
        END WHILE;
    ELSE
        WHILE _amount > 0 DO
            SET last_id    = (SELECT AddRandomNieruchomosc(NULL, NULL)); -- przypisanie spowoduje nie wysyłanie wyniku na ekran
            SET _amount=_amount - 1;
        END WHILE;
    END IF;
END$$

-- dodana mozliwosc dodawania nieruchomosci w zasiegu tego samego miasta i ulicy
/*
    komentarze!!!

    Funkcja dodaje nieruchomość o numerze _number do nieruchomości dla miasta i ulicy jak dla nieruchomości o id = _id.
    jeśli _id jest NULL, to losuje nową nieruchomość
    jeśli _number jest NULL, to losuje _number dla nieruchomości _id

    złe nazewnictwo zmiennych (mylne)


    zła kolejność i logika w układzie warunków

    IF _number IS NOT NULL THEN
        IF _id IS NULL THEN


    jeśli _number podano (nie jest NULL) to oczekujemy, ze zostanie dopisany ten numer do istniejącej nieruchomości o konkretnym ID


    chodzi o to aby funkcja realizowała 3 przypadki:

    1) dodaj NOWĄ nieruchomość (o losowym mieście, ulicy, numerze) _id = NULL, _number = NULL
    2) dodaj NOWĄ nieruchomość (o losowym numerze) do istniejącej, czyli jeśli mamy Łódz Piotrkowska 43, to dodaj Łódz, Piotrkowska xx         _id = 1234, _number = NULL
    3) dodaj NOWĄ  nieruchomość o podanym numerze do istniejącej, czyli jeśli mamy Łódz Piotrkowska 43, to dodaj Łódz, Piotrkowska 54          _id = 1234, _number = 54

    natomiast nie chodzi o to aby losować miasto i ulicę a numer byłby podany (czyli dodaj Łask, Łódzka 32; Warszawa, Saska Kępa 32; Rumia, Morska 32)...
    czyli układ _id = NULL a _number jest nie NULL nie jest nam potrzebny...

    i wtedy można zrobić pętlę...

   czyli AddRandomNieruchomosc do przeróbki


   AddLokale(_NieruchomoscID, _amount) -> od 1 .. _amount, jeśli _amount jest NULL, to np. niech będzie 300...



*/

DROP FUNCTION IF EXISTS AddRandomNieruchomosc$$
CREATE FUNCTION AddRandomNieruchomosc( _number varchar(4), _id int unsigned) RETURNS INT
BEGIN
    DECLARE city   VARCHAR(32);
    DECLARE street VARCHAR(64);
    DECLARE rand_number, rand_city_id, rand_street_id INT;
    DECLARE nier_exists BOOL;
    IF (_id IS NOT NULL) THEN
        IF (_number IS NULL) THEN
            REPEAT
                SET rand_number		= RAND()*200+1;
                SET city			= (SELECT miasto FROM slownik.miasta WHERE id = rand_city_id);
                SET street			= (SELECT nazwa FROM slownik.ulice WHERE id = rand_street_id);
                SET nier_exists		= (SELECT id FROM Nieruchomosc WHERE (miasto = city) AND (ulica  = street) AND (numer = _number) LIMIT 1) IS NOT NULL;
            UNTIL NOT nier_exists
            END REPEAT;
        ELSE
            SET street          = (SELECT ulica FROM Nieruchomosc WHERE id=_id limit 1);
            SET city            = (SELECT miasto FROM Nieruchomosc WHERE id=_id limit 1);
        END IF;
    ELSE
        REPEAT
            SET rand_number    = RAND()*200+1;
            SET rand_street_id = RAND()*1000+1;
            SET rand_city_id   = CAST((RAND()*590+1) AS CHAR(4));
            SET city        = (SELECT miasto FROM slownik.miasta WHERE id = rand_city_id);
            SET street      = (SELECT nazwa FROM slownik.ulice WHERE id = rand_street_id);
            SET nier_exists = (SELECT id FROM Nieruchomosc WHERE (miasto = city) AND (ulica = street) AND (numer = rand_number) LIMIT 1) IS NOT NULL;
        UNTIL NOT nier_exists END REPEAT;
    END IF;

    INSERT INTO Nieruchomosc VALUES (null, city, street, rand_number);
    RETURN LAST_INSERT_ID();
END$$

DELIMITER ;

call AddManyNieruchomosci(120, NULL);

/*
call AddManyNieruchomosci(5,5);
call AddManyNieruchomosci(5,NULL);
select AddRandomNieruchomosc(NULL, 5); */
-- 
-------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- 
-------------------------------------------------------------------------------------------------------------------------------------------------------------------
DELIMITER //

DROP FUNCTION IF EXISTS AddRandomLokal //
CREATE FUNCTION AddRandomLokal(property_id INT) RETURNS INT
BEGIN
 DECLARE rproperty_id INT;
    DECLARE rnumber VARCHAR(5);

    -- SET rproperty_id = 1+(SELECT COUNT(*) FROM Property)*RAND();
    SET rnumber = CONCAT(CAST(RndValue(100) AS char), RndStr(1,1));

	INSERT INTO Premises VALUES (null,property_id,rnumber); -- podaję nieruchomość, ale można też losować
    RETURN LAST_INSERT_ID();
END //

DROP FUNCTION IF EXISTS RndValue //
CREATE FUNCTION RndValue(rng INT) RETURNS INT
BEGIN
    RETURN 1 + RAND() * rng;
END //

DELIMITER ;