use PortalA;

ALTER TABLE    Uzytkownik MODIFY nazwa VARCHAR(32) CHARACTER SET cp1250 NULL;
ALTER TABLE    Uzytkownik MODIFY login VARCHAR(32) CHARACTER SET cp1250 NULL;
ALTER TABLE    Uzytkownik MODIFY haslo VARCHAR(32) CHARACTER SET cp1250 NULL;

ALTER TABLE    Lokal MODIFY numer  VARCHAR(4) CHARACTER SET cp1250 NULL;
ALTER TABLE    Nieruchomosc MODIFY numer  VARCHAR(4)  CHARACTER SET cp1250 NULL;

DELIMITER  $$
DROP PROCEDURE IF EXISTS AddManyNieruchomosci$$
CREATE PROCEDURE AddManyNieruchomosci(_amount INT UNSIGNED, _max int unsigned)
BEGIN
  DECLARE last_id, rand_max INT UNSIGNED;
  SET last_id=(SELECT AddRandomNieruchomosc(NULL,0));
  WHILE _amount > 1 DO
    SELECT AddRandomNieruchomosc(_max,last_id);
    SET _amount=_amount - 1;
    REPEAT 
		SET rand_max=RAND()*_max + 1;
		UNTIL rand_max = _max
    END REPEAT;
    SET _max = rand_max;
  END WHILE; 
END$$


DROP FUNCTION IF EXISTS AddRandomNieruchomosc$$
CREATE FUNCTION AddRandomNieruchomosc( _number varchar(4), _id int unsigned) RETURNS INT
BEGIN
    DECLARE city VARCHAR(30); 
    DECLARE street VARCHAR(41);
    DECLARE number VARCHAR(4);
    DECLARE rand_number, rand_city, rand_street INT;
    DECLARE nier_exists BOOL;
    -- dodana mozliwosc dodawania nieruchomosci w zasiegu tego samego miasta i ulicy
    IF _number IS NULL THEN
  SET number=_number;
  SET street=(SELECT ulica from Nieruchomosc where id=_id limit 1);
  SET city=(SELECT miasto from Nieruchomosc where id=_id limit 1);
    ELSE
  REPEAT
   SET rand_number = RAND()*200+1;
   SET rand_street = RAND()*1000+1;
   SET rand_city   = CAST((RAND()*590+1)AS CHAR(4));
   SET city        = (SELECT miasto FROM slownik.miasta WHERE id = rand_city);
   SET street      = (SELECT nazwa FROM slownik.ulice   WHERE id = rand_street);
   SET number      = rand_number; -- CAST(rand_number AS CHAR(4));
   SET nier_exists = (SELECT id from Nieruchomosc where miasto=city AND ulica=street AND numer = number LIMIT 1) IS NOT NULL;
  UNTIL NOT nier_exists
  END REPEAT;
    END IF;
    INSERT INTO Nieruchomosc VALUES (null, city, street, number);
    RETURN LAST_INSERT_ID();
END$$


DROP PROCEDURE IF EXISTS AddManyRandomNieruchomosci$$
CREATE PROCEDURE AddManyRandomNieruchomosci(_amount INT UNSIGNED)
BEGIN
  WHILE _amount > 0 DO
    SELECT AddRandomNieruchomosc(NULL,0);
    SET _amount=_amount - 1;
  END WHILE; 
END$$

DELIMITER ;

CALL AddManyNieruchomosci(3,2);

SHOW CREATE TABLE slownik.miasta;
