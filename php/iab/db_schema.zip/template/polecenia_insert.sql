USE PortalA;
-----------------------
INSERT INTO Pokoj(id,nazwa) VALUES 
(01,'Lazienka'),
(02,'WC'),
(03,'Kuchnia'),
(04,'Inne');
-----------------------
INSERT INTO Rodzaj(id,nazwa) VALUES
(10,'Zimna'),
(11,'Ciepla');
-----------------------
INSERT INTO Administrator VALUES
(1,'Name1','Jarek123','haslo123',1),
(2,'Name2','Aga32','trudnehaslo1',1),
(3,'Name3','Kazio69','w@zne9',0);
------------------------
INSERT INTO Nieruchomosc VALUES
(1,'Lublin','ulica Warszawska',2),
(2,'Krakow','ulica Zielona',123),
(3,'Lodz','aleja Politechniki',51),
(4,'Lublin','ulica Kwiatowa',22),
(5,'Krakow','ulica Polna',12),
(6,'Lodz','aleja Piotrkowska',121);
-------------------------
INSERT INTO AdministratorNieruchomosc VALUES
(null,1,1),
(null,2,2),
(null,3,3),
(null,1,4),
(null,2,5),
(null,3,6);
------------------------
/*LOAD DATA INFILE 'uzytkownicy.txt'
INTO TABLE Uzytkownik; -- 10*/
INSERT INTO Uzytkownik VALUES
(1,'Name1','mirek2','aga32',1),
(2,'Name2','mazena3','miroslaw67',1),
(3,'Name3','adam42','j@kieSLatwe3',1),
(4,'Name4','bea88','costrzebawym',0),
(5,'Name5','czeslaw50','marysia2',1),
(6,'Name6','danka66','olaf11',0),
(7,'Name7','eliza55','kwiatek123',1),
(8,'Name8','franek11','LomtjjZ2',1),
(9,'Name9','kaska34','konwalie8',0),
(10,'Name10','wojtek44','k*rwasz123',0);
------------------------
-- TUTAJ TRZA PACZYC
------------------------
INSERT INTO Lokal VALUES 
(1,2,'23c'),
(2,2,'10a'),
(3,3,'19'),
(4,1,'8'),
(5,1,'12'),
(6,1,'14b'),
(7,3,'12a'),
(8,3,'3'),
(9,2,'4'),
(10,2,'6');
------------------------
INSERT INTO UzytkownikLokal VALUES
(null,3,1),
(null,2,2),
(null,4,3),
(null,9,4),
(null,9,5),
(null,8,6),
(null,5,7),
(null,1,8),
(null,10,9),
(null,2,10);
INSERT INTO Wodomierz VALUES
(1,1,10,1,2345),
(2,1,11,1,1234),
(3,1,11,2,5432),
(4,2,11,2,7801),
(5,2,10,2,7802),
(6,3,10,2,6589),
(7,3,11,1,8721),
(8,4,11,1,4521),
(9,4,10,4,2124),
(10,4,11,2,3188),
(11,5,10,4,3222),
(12,5,11,2,7777),
(13,6,11,3,1111),
(14,7,11,2,2222),
(15,8,11,1,5555),
(16,9,11,3,9126),
(17,10,11,1,5241);
------------------------
INSERT INTO Odczyt VALUES
(null,1,'2017-03-02',19.34),
(null,2,'2017-03-03',29.34),
(null,3,'2017-03-04',9.14),
(null,4,'2017-03-05',8.34),
(null,5,'2017-03-06',23.77),
(null,6,'2017-03-07',11.22),
(null,7,'2017-03-08',7.34),
(null,8,'2017-03-09',3.57),
(null,9,'2017-03-10',5.23),
(null,10,'2017-03-11',6.12),
(null,11,'2017-03-12',89.22),
(null,12,'2017-03-13',99.31),
(null,13,'2017-03-14',51.22),
(null,14,'2017-03-15',61.22),
(null,15,'2017-03-16',71.22),
(null,16,'2017-03-17',81.22),
(null,17,'2017-03-18',22.22);