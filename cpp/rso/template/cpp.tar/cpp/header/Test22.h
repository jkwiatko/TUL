class Test22 {
	int var;
};
