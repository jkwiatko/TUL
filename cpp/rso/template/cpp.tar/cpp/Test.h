#pragma once

class Test {
	int field;
    
	public:
	void fun(int f);
	void reference(int in, int& out);
	void pointer(int* i);
};
