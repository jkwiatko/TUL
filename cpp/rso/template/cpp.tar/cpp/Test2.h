class Test2 {
	int var;
};
