  #include <assert.h>
  #include <stdlib.h>
  #include <stdio.h>

  void push(int a);
  int pop(void);
  void clear(void);
  void init(void);
  void finalize(void);
