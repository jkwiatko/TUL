#include "stos.h"

static int top; /* pierwsze wolne miejsce na stosie */
static int *dane;
static int size;

void init()
{
	top=0;
	size=0;
	dane=0;
}

void finalize()
{
  free(dane);
}

void clear()
{
	top=0;
}

void push(int a)
{
	if(top>=size)
	{
	  int newsize=(size+1);
	  int* ndane=(int*)realloc(dane,newsize*sizeof(int));
	  if(ndane)
	    dane=ndane;
	  else
	  {
	    free(dane);
	    abort();
	  }
	  printf("\n\nRozmiar stosu %d -> %d\n",size,newsize);
	  size=newsize;
	}
	dane[top++]=a;
}

int pop()
{
	int popdane;
	assert(top>0);
	popdane=dane[--top];
	if(top<size-1)
	{
	int newsize=(size-1);
	int* ndane=(int*)realloc(dane,newsize*sizeof(int));
	  if(ndane)
	    dane=ndane;
	  else
	  {
	    free(dane);
	  }
	  printf("\n\nRozmiar stosu %d -> %d\n",size,newsize);
	  size=newsize;
	 }
	 return popdane;
}
